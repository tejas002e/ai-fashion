---
name: Chroma Fashion AI identity
description: User-stated product name and visual constraints for future UI work.
---

The product is called Chroma Fashion AI. Preserve its dark theme, gradients, glassmorphism, typography, product cards, colour swatches, and working animations; avoid generic dashboard restyles.

**Why:** the user explicitly identified the brand and the visual identity that must remain.

**How to apply:** keep future UI changes targeted to requested fixes and carry the product name and existing style through all application sections.
