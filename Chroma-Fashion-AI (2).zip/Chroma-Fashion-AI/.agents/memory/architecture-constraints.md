---
name: Architecture constraints
description: User-stated technology and dependency boundaries for this project.
---

Keep the existing Streamlit and Python architecture unless a specific, demonstrable issue requires a change. Continue using the existing computer vision and machine-learning libraries where appropriate, including OpenCV, NumPy, scikit-learn, and Pillow. Do not introduce React, Node.js, a separate API server, a database, external AI APIs, or paid services merely to make the project appear more advanced. Avoid unnecessary dependency upgrades; establish a compatible, reproducible dependency set based on what the application actually requires.

**Why:** the user explicitly set these project constraints.

**How to apply:** use these boundaries when changing architecture, selecting dependencies, or proposing infrastructure for this project.
